Configuration Main
{
Param ( [string] $nodeName )
#$nodeName = "StandardNode"

Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xNetworking

Node $nodeName
    {
    xWaitforDisk Disk2
        {
        DiskNumber = 2
        RetryIntervalSec = 60
        }
    xDisk FVolume
	    {
        DiskNumber = 2
        DriveLetter = 'F'
        }

	WindowsFeature TelnetClient
        {
        Ensure = 'Present'
        Name = 'Telnet-Client'
        }

	File CreateFile 
		{
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
        }
	
#	xFirewall WebFirewallRule 
#        {
#        Name = "AAA Web-Server-TCP-In" 
#        DisplayName = "AAA Web Server (TCP-In)" 
#        Group = "IIS Incoming Traffic"  
#        Ensure = "Present" 
#        Enabled = "True"
#        Action = "Allow"
#		Profile = ("Domain", "Private", "Public")
#        Direction = "Inbound" 
#        LocalPort = "80" 
#        Protocol = "TCP"  
#        Description = "IIS allow incoming web site traffic." 
#        }
	}
} 
