Configuration Main
{
Param 
    (
    [string[]]$NodeName

    [Parameter(Mandatory)]
    [String]$DomainName,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$Admincreds,
    )

Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xComputerManagement

[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $AdminCreds.Password)

Node $NodeName
    {
    xWaitforDisk Disk2
        {
        DiskNumber = 2
        RetryIntervalSec = 60
        }

    xDisk FVolume
	{
        DiskNumber = 2
        DriveLetter = 'F'
        }

    WindowsFeature TelnetClient
        {
        Ensure = 'Present'
        Name = 'Telnet-Client'
        }

    File CreateFile 
	{
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
        }

    xComputer JoinDomain
        {
        Name = $NodeName  
        DomainName = $DomainName
        Credential = $DomainCreds
        }
    }
} 
