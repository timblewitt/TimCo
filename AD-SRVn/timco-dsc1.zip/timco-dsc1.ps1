Configuration Main
{
Param 
  (
    [string[]]$NodeName,

    [Parameter(Mandatory)]
    [string[]]$DNSServerAddress
  )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xNetworking
Import-DscResource -ModuleName xStorage

Node $NodeName
    {
    xDnsServerAddress DNSServer
      {
        Address = $DNSServerAddress
        InterfaceAlias = "Ethernet"
        AddressFamily  = "IPv4"
      }

    xWaitforDisk Disk2
      {
        DiskNumber = 2
        RetryIntervalSec = 60
      }

    xDisk FVolume
      {
        DiskNumber = 2
        DriveLetter = 'F'
      }

    WindowsFeature TelnetClient
      {
        Ensure = 'Present'
        Name = 'Telnet-Client'
      }

    File CreateFile 
      {
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
      }
    }
} 
