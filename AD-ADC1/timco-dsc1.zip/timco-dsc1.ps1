Configuration Main
{
Param 
    (
    [string[]]$NodeName = 'localhost'
    )

Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xComputerManagement

Node $nodeName
    {
    LocalConfigurationManager            
        {            
        ActionAfterReboot = 'ContinueConfiguration'            
        ConfigurationMode = 'ApplyOnly'            
        RebootNodeIfNeeded = $true            
        } 

    xWaitforDisk Disk2
        {
        DiskNumber = 2
        RetryIntervalSec = 60
        }

    xDisk FVolume
	{
        DiskNumber = 2
        DriveLetter = 'F'
        }

    WindowsFeature TelnetClient
        {
        Ensure = 'Present'
        Name = 'Telnet-Client'
        }
    
    WindowsFeature DNS 
        { 
        Ensure = "Present" 
        Name = "DNS"
        }

    WindowsFeature ADDSInstall 
        { 
        Ensure = "Present" 
        Name = "AD-Domain-Services"
        }  

    File CreateFile 
	{
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
        }
    }
} 
