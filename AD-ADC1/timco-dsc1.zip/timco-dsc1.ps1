Configuration Main
{
Param 
    (
    [string[]]$NodeName = 'localhost',

    [Parameter(Mandatory)]
    [String]$DomainName,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$Admincreds,

    [Int]$RetryCount=20,
    [Int]$RetryIntervalSec=30
    )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xNetworking
Import-DscResource -ModuleName xActiveDirectory
Import-DscResource -ModuleName xPendingReboot

PSDscAllowDomainUser = $true

$password =  ConvertTo-SecureString $Admincreds.Password -AsPlainText -Force
[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $password)

Node $AllNodes.NodeName
    {
    LocalConfigurationManager            
        {            
        ActionAfterReboot = 'ContinueConfiguration'            
        ConfigurationMode = 'ApplyOnly'            
        RebootNodeIfNeeded = $true            
        } 

    xWaitforDisk Disk2
        {
        DiskNumber = 2
        RetryIntervalSec = 60
        }

    xDisk FVolume
	{
        DiskNumber = 2
        DriveLetter = 'F'
        }

    File CreateFile 
	{
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
        }

    WindowsFeature TelnetClient
        {
        Ensure = 'Present'
        Name = 'Telnet-Client'
        }
    
    WindowsFeature DNS 
        { 
        Ensure = "Present" 
        Name = "DNS"
        }

    xDnsServerAddress DnsServerAddress 
        { 
        Address        = '127.0.0.1' 
        InterfaceAlias = 'Ethernet'
        AddressFamily  = 'IPv4'
        DependsOn = "[WindowsFeature]DNS"
        }

    WindowsFeature ADDSInstall 
        { 
        Ensure = "Present" 
        Name = "AD-Domain-Services"
        }  

    xADDomain FirstDC 
        {
        DomainName = $DomainName
        DomainAdministratorCredential = $DomainCreds
        SafemodeAdministratorPassword = $DomainCreds
        DatabasePath = "F:\NTDS"
        LogPath = "F:\NTDS"
        SysvolPath = "F:\SYSVOL"
        DependsOn = "[WindowsFeature]ADDSInstall","[xDnsServerAddress]DnsServerAddress","[xDisk]FVolume"
        }

    xWaitForADDomain DscForestWait
        {
        DomainName = $DomainName
        DomainUserCredential = $DomainCreds
        RetryCount = $RetryCount
        RetryIntervalSec = $RetryIntervalSec
        DependsOn = "[xADDomain]FirstDC"
        } 

    xPendingReboot Reboot1
        { 
        Name = "RebootServer"
        DependsOn = "[xWaitForADDomain]DscForestWait"
        }

    }
} 
