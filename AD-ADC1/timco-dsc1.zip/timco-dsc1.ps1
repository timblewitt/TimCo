Configuration Main
{
Param 
    (
    [string[]]$NodeName = 'localhost',

    [Parameter(Mandatory)]
    [String]$DomainName,

    [Parameter(Mandatory)]
    [System.Management.Automation.PSCredential]$Admincreds,

    [Int]$RetryCount=20,
    [Int]$RetryIntervalSec=10
    )

Import-DscResource -ModuleName PSDesiredStateConfiguration
Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xNetworking
Import-DscResource -ModuleName xActiveDirectory
Import-DscResource -ModuleName xPendingReboot

[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $AdminCreds.Password)

Node $AllNodes.NodeName
  {
    LocalConfigurationManager            
      {            
        ActionAfterReboot = 'ContinueConfiguration'            
        ConfigurationMode = 'ApplyOnly'            
        RebootNodeIfNeeded = $true      
	AllowModuleOverWrite = $true      
      } 

    xWaitforDisk Disk2
      {
        DiskNumber = 2
          RetryIntervalSec = $RetryIntervalSec
          RetryCount = $RetryCount
      }

    xDisk FVolume
      {
        DiskNumber = 2
        DriveLetter = 'F'
      }

    File CreateFile 
      {
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
      }

    WindowsFeature TelnetClient
      {
        Ensure = 'Present'
        Name = 'Telnet-Client'
      }
    
    WindowsFeature DNS 
      { 
        Ensure = "Present" 
        Name = "DNS"
      }

    WindowsFeature DNSTools
      { 
        Ensure = 'Present' 
        Name = 'RSAT-DNS-SERVER' 
      }

    WindowsFeature ADDSInstall 
      { 
        Ensure = "Present" 
        Name = "AD-Domain-Services"
      }  

    WindowsFeature ADDSTools
      { 
        Ensure = 'Present' 
        Name = 'RSAT-ADDS' 
      }

    xADDomain FirstDC 
      {
        DomainName = $DomainName
        DomainAdministratorCredential = $DomainCreds
        SafemodeAdministratorPassword = $DomainCreds
        DatabasePath = "F:\NTDS"
        LogPath = "F:\NTDS"
        SysvolPath = "F:\SYSVOL"
        DependsOn = "[WindowsFeature]ADDSInstall","[xDisk]FVolume"
      }

    xWaitForADDomain DscForestWait
      {
        DomainName = $DomainName
        DomainUserCredential = $DomainCreds
        RetryCount = $RetryCount
        RetryIntervalSec = $RetryIntervalSec
        DependsOn = "[xADDomain]FirstDC"
      } 

    xADRecycleBin RecycleBin
      {
        EnterpriseAdministratorCredential = $DomainCreds
        ForestFQDN = $DomainName
        DependsOn = '[xWaitForADDomain]DscForestWait'
      }

    xPendingReboot Reboot1
      { 
        Name = "RebootServer"
        DependsOn = "[xWaitForADDomain]DscForestWait"
      }

    $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
    xADOrganizationalUnit Managed
      {
        Name = 'Managed1'
        Path = "$DomainRoot"
        ProtectedFromAccidentalDeletion = $true
        Credential = $DomainCreds
        Ensure = 'Present'
        DependsOn = "[xPendingReboot]Reboot1"
      }




#    $DomainRoot = "DC=$($DomainName -replace '\.',',DC=')"
#    $DependsOn_OU = @()

#    ForEach ($OU in $ConfigurationData.NonNodeData.OUData) {
                
#      xADOrganizationalUnit "OU_$OU"
#        {
#          Name = $OU
#          Path = "$DomainRoot"
#          ProtectedFromAccidentalDeletion = $true
#          Credential = $DomainCreds
#          Ensure = 'Present'
#          DependsOn = '[xADRecycleBin]RecycleBin'
#        }

#        $DependsOn_OU += "[xADOrganizationalUnit]OU_$OU"
#      }

  }
} 
