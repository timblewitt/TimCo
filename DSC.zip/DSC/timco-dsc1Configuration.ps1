Configuration Main
{
Param ( [string] $nodeName,
		[string] $domainName,
        [System.Management.Automation.PSCredential]$Admincreds
 )

Import-DscResource -ModuleName xStorage
Import-DscResource -ModuleName xNetworking
Import-DscResource -ModuleName xActiveDirectory
Import-DscResource -ModuleName xPendingReboot

[System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

Node $nodeName
    {
    xWaitforDisk Disk2
        {
        DiskNumber = 2
        RetryIntervalSec = 60
        }

    xDisk FVolume
	    {
        DiskNumber = 2
        DriveLetter = 'F'
        }

	WindowsFeature TelnetClient
        {
        Ensure = 'Present'
        Name = 'Telnet-Client'
        }

	WindowsFeature DNS
        {
        Ensure = 'Present'
        Name = 'DNS'
        }

    xDnsServerAddress DnsServerAddress 
        { 
        Address        = '127.0.0.1' 
        InterfaceAlias = 'Ethernet'
        AddressFamily  = 'IPv4'
        DependsOn = "[WindowsFeature]DNS"
        }

	WindowsFeature ADDSInstall
        {
        Ensure = 'Present'
        Name = 'AD-Domain-Services'
        }

    xADDomain FirstDS 
        {
        DomainName = $DomainName
        DomainAdministratorCredential = $DomainCreds
        SafemodeAdministratorPassword = $DomainCreds
        DatabasePath = "F:\NTDS"
        LogPath = "F:\NTDS"
        SysvolPath = "F:\SYSVOL"
        DependsOn = "[WindowsFeature]ADDSInstall","[xDnsServerAddress]DnsServerAddress"
        }
	
    xWaitForADDomain DscForestWait
        {
        DomainName = $DomainName
        DomainUserCredential = $DomainCreds
        RetryCount = $RetryCount
        RetryIntervalSec = $RetryIntervalSec
        DependsOn = "[xADDomain]FirstDS"
        } 

    xPendingReboot Reboot1
        { 
        Name = "RebootServer"
        DependsOn = "[xWaitForADDomain]DscForestWait"
        }

	File CreateFile 
		{
        DestinationPath = 'F:\Software\Readme.txt'
        Ensure = "Present"
        Contents = 'Store all software in this folder.'
        }
	
#	xFirewall WebFirewallRule 
#        {
#        Name = "AAA Web-Server-TCP-In" 
#        DisplayName = "AAA Web Server (TCP-In)" 
#        Group = "IIS Incoming Traffic"  
#        Ensure = "Present" 
#        Enabled = "True"
#        Action = "Allow"
#		Profile = ("Domain", "Private", "Public")
#        Direction = "Inbound" 
#        LocalPort = "80" 
#        Protocol = "TCP"  
#        Description = "IIS allow incoming web site traffic." 
#        }
	}
} 
